import { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { HomeScreen } from './mobile/HomeScreen';
import { PreferenceScreen } from './mobile/PreferenceScreen';
import { RecommendationScreen } from './mobile/RecommendationScreen';
import { CoffeeDetailScreen } from './mobile/CoffeeDetailScreen';

type Screen = 'home' | 'preference' | 'recommendation' | 'detail';

interface MobileAppProps {
  onBack: () => void;
}

export interface UserPreference {
  acidity: number;
  body: number;
  aroma: number;
  weather: string;
  time: string;
}

export interface Coffee {
  id: number;
  name: string;
  origin: string;
  acidity: number;
  body: number;
  aroma: number;
  description: string;
  price: string;
  image: string;
  roastLevel: string;
  flavorNotes: string[];
  matchScore?: number;
}

export function MobileApp({ onBack }: MobileAppProps) {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [userPreference, setUserPreference] = useState<UserPreference | null>(null);
  const [selectedCoffee, setSelectedCoffee] = useState<Coffee | null>(null);

  const handleStartRecommendation = () => {
    setCurrentScreen('preference');
  };

  const handlePreferenceSubmit = (preference: UserPreference) => {
    setUserPreference(preference);
    setCurrentScreen('recommendation');
  };

  const handleCoffeeSelect = (coffee: Coffee) => {
    setSelectedCoffee(coffee);
    setCurrentScreen('detail');
  };

  const handleBackToHome = () => {
    setCurrentScreen('home');
    setUserPreference(null);
    setSelectedCoffee(null);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      {/* Exit Button */}
      <button
        onClick={onBack}
        className="fixed top-4 left-4 z-50 bg-white text-gray-700 px-4 py-2 rounded-full shadow-lg hover:bg-gray-50 transition-colors flex items-center gap-2"
      >
        <ArrowLeft className="w-4 h-4" />
        Kembali ke Landing Page
      </button>

      {/* Mobile Frame */}
      <div className="relative w-full max-w-md">
        {/* Phone Frame */}
        <div className="relative bg-black rounded-[3rem] p-3 shadow-2xl">
          {/* Notch */}
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-40 h-7 bg-black rounded-b-3xl z-10"></div>
          
          {/* Screen */}
          <div className="bg-white rounded-[2.5rem] overflow-hidden relative" style={{ height: '700px' }}>
            {/* Status Bar */}
            <div className="absolute top-0 left-0 right-0 h-12 bg-gradient-to-r from-amber-900 to-orange-900 flex items-center justify-between px-8 text-white z-10">
              <span>9:41</span>
              <div className="flex items-center gap-1">
                <div className="w-4 h-4 border-2 border-white rounded-sm"></div>
                <div className="w-4 h-4 border-2 border-white rounded-sm"></div>
                <div className="w-4 h-4 border-2 border-white rounded-sm"></div>
              </div>
            </div>

            {/* App Content */}
            <div className="h-full overflow-y-auto">
              {currentScreen === 'home' && (
                <HomeScreen onStart={handleStartRecommendation} />
              )}
              {currentScreen === 'preference' && (
                <PreferenceScreen
                  onSubmit={handlePreferenceSubmit}
                  onBack={handleBackToHome}
                />
              )}
              {currentScreen === 'recommendation' && userPreference && (
                <RecommendationScreen
                  preference={userPreference}
                  onCoffeeSelect={handleCoffeeSelect}
                  onBack={handleBackToHome}
                />
              )}
              {currentScreen === 'detail' && selectedCoffee && (
                <CoffeeDetailScreen
                  coffee={selectedCoffee}
                  onBack={() => setCurrentScreen('recommendation')}
                />
              )}
            </div>
          </div>
        </div>

        {/* Home Button */}
        <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-32 h-1 bg-white rounded-full"></div>
      </div>
    </div>
  );
}
