import { ArrowLeft, Sparkles, TrendingUp } from 'lucide-react';
import { UserPreference, Coffee } from '../MobileApp';
import { useMemo, useState, useEffect } from 'react';

interface RecommendationScreenProps {
  preference: UserPreference;
  onCoffeeSelect: (coffee: Coffee) => void;
  onBack: () => void;
}

// Mock coffee database
const coffeeDatabase: Coffee[] = [
  {
    id: 1,
    name: 'Gayo Arabica',
    origin: 'Aceh, Indonesia',
    acidity: 8,
    body: 7,
    aroma: 9,
    description: 'Kopi Arabica dari dataran tinggi Gayo dengan cita rasa yang khas dan aroma yang kuat',
    price: 'Rp 85.000/250g',
    image: 'coffee beans gayo',
    roastLevel: 'Medium',
    flavorNotes: ['Cokelat', 'Karamel', 'Buah Berry']
  },
  {
    id: 2,
    name: 'Toraja Kalosi',
    origin: 'Sulawesi, Indonesia',
    acidity: 6,
    body: 9,
    aroma: 8,
    description: 'Kopi premium dari Toraja dengan body yang kental dan rasa yang kompleks',
    price: 'Rp 95.000/250g',
    image: 'coffee beans toraja',
    roastLevel: 'Dark',
    flavorNotes: ['Earthy', 'Cokelat Hitam', 'Rempah']
  },
  {
    id: 3,
    name: 'Java Preanger',
    origin: 'Jawa Barat, Indonesia',
    acidity: 7,
    body: 8,
    aroma: 7,
    description: 'Kopi klasik dari Jawa Barat dengan keseimbangan rasa yang sempurna',
    price: 'Rp 75.000/250g',
    image: 'coffee beans java',
    roastLevel: 'Medium-Dark',
    flavorNotes: ['Kacang', 'Cokelat', 'Manis']
  },
  {
    id: 4,
    name: 'Wamena Papua',
    origin: 'Papua, Indonesia',
    acidity: 9,
    body: 6,
    aroma: 8,
    description: 'Kopi organik dari Papua dengan keasaman yang cerah dan aroma floral',
    price: 'Rp 100.000/250g',
    image: 'coffee beans papua',
    roastLevel: 'Light',
    flavorNotes: ['Floral', 'Citrus', 'Madu']
  },
  {
    id: 5,
    name: 'Bali Kintamani',
    origin: 'Bali, Indonesia',
    acidity: 8,
    body: 7,
    aroma: 7,
    description: 'Kopi dari Kintamani dengan karakter fruity dan segar',
    price: 'Rp 80.000/250g',
    image: 'coffee beans bali',
    roastLevel: 'Light-Medium',
    flavorNotes: ['Jeruk', 'Bunga', 'Lemon']
  },
  {
    id: 6,
    name: 'Mandailing Sumatera',
    origin: 'Sumatera Utara, Indonesia',
    acidity: 5,
    body: 9,
    aroma: 8,
    description: 'Kopi robusta premium dengan body yang sangat kental',
    price: 'Rp 70.000/250g',
    image: 'coffee beans mandailing',
    roastLevel: 'Dark',
    flavorNotes: ['Herbal', 'Tembakau', 'Tanah']
  },
  {
    id: 7,
    name: 'Flores Bajawa',
    origin: 'NTT, Indonesia',
    acidity: 7,
    body: 7,
    aroma: 8,
    description: 'Kopi dengan rasa seimbang dan aroma yang menawan',
    price: 'Rp 90.000/250g',
    image: 'coffee beans flores',
    roastLevel: 'Medium',
    flavorNotes: ['Cokelat', 'Vanilla', 'Kacang']
  },
  {
    id: 8,
    name: 'Lampung Robusta',
    origin: 'Lampung, Indonesia',
    acidity: 4,
    body: 8,
    aroma: 6,
    description: 'Robusta berkualitas dengan rasa yang strong dan cocok untuk espresso',
    price: 'Rp 60.000/250g',
    image: 'coffee beans lampung',
    roastLevel: 'Dark',
    flavorNotes: ['Pahit', 'Cokelat', 'Smoky']
  }
];

export function RecommendationScreen({ preference, onCoffeeSelect, onBack }: RecommendationScreenProps) {
  const [isLoading, setIsLoading] = useState(true);

  // Simulate ML processing time
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1800); // 1.8 seconds to match research data
    return () => clearTimeout(timer);
  }, []);

  // K-Nearest Neighbor algorithm implementation
  const recommendations = useMemo(() => {
    // Calculate Euclidean distance for each coffee
    const coffeeWithScores = coffeeDatabase.map(coffee => {
      const acidityDiff = Math.pow(coffee.acidity - preference.acidity, 2);
      const bodyDiff = Math.pow(coffee.body - preference.body, 2);
      const aromaDiff = Math.pow(coffee.aroma - preference.aroma, 2);
      
      const distance = Math.sqrt(acidityDiff + bodyDiff + aromaDiff);
      
      // Convert distance to match score (0-100)
      const maxDistance = Math.sqrt(3 * Math.pow(10, 2)); // Maximum possible distance
      const matchScore = Math.round((1 - distance / maxDistance) * 100);
      
      return {
        ...coffee,
        matchScore
      };
    });

    // Sort by match score and return top 5
    return coffeeWithScores
      .sort((a, b) => b.matchScore! - a.matchScore!)
      .slice(0, 5);
  }, [preference]);

  if (isLoading) {
    return (
      <div className="min-h-full bg-gradient-to-br from-amber-50 to-orange-50 pt-12 flex items-center justify-center">
        <div className="text-center px-6">
          <div className="w-20 h-20 mx-auto mb-6 relative">
            <div className="absolute inset-0 border-4 border-amber-200 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-amber-900 rounded-full border-t-transparent animate-spin"></div>
            <Sparkles className="w-10 h-10 text-amber-900 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
          </div>
          <h2 className="text-gray-800 mb-2">Menganalisis Preferensi</h2>
          <p className="text-gray-600">Algoritma KNN sedang mencari kopi terbaik untuk Anda...</p>
          <p className="text-amber-900 mt-4">~1.8 detik</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-full bg-gradient-to-br from-amber-50 to-orange-50 pt-12">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-900 to-orange-900 px-6 py-6 flex items-center gap-3">
        <button onClick={onBack} className="text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-white">Rekomendasi Untuk Anda</h1>
      </div>

      <div className="px-6 py-6">
        {/* Info Banner */}
        <div className="bg-white rounded-xl p-4 mb-6 flex items-start gap-3">
          <Sparkles className="w-6 h-6 text-amber-900 flex-shrink-0 mt-1" />
          <div>
            <h3 className="text-gray-800 mb-1">Rekomendasi AI</h3>
            <p className="text-gray-600">
              Berdasarkan preferensi Anda, kami menemukan {recommendations.length} kopi yang cocok
            </p>
          </div>
        </div>

        {/* Recommendations List */}
        <div className="space-y-4">
          {recommendations.map((coffee, index) => (
            <div
              key={coffee.id}
              onClick={() => onCoffeeSelect(coffee)}
              className="bg-white rounded-2xl shadow-md overflow-hidden cursor-pointer hover:shadow-xl transition-shadow"
            >
              <div className="flex gap-4 p-4">
                <div className="flex-shrink-0 w-24 h-24 bg-gradient-to-br from-amber-900 to-orange-900 rounded-xl flex items-center justify-center">
                  <span className="text-white">{coffee.name.substring(0, 2)}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 className="text-gray-800">{coffee.name}</h3>
                    {index === 0 && (
                      <div className="flex-shrink-0 bg-amber-100 text-amber-900 px-2 py-1 rounded-full flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        <span>Top</span>
                      </div>
                    )}
                  </div>
                  <p className="text-gray-500 mb-2">{coffee.origin}</p>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex-1 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-amber-600 to-orange-600 h-2 rounded-full"
                        style={{ width: `${coffee.matchScore}%` }}
                      ></div>
                    </div>
                    <span className="text-amber-900">{coffee.matchScore}%</span>
                  </div>
                  <p className="text-gray-700">{coffee.price}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Info Footer */}
        <div className="mt-6 bg-amber-50 rounded-xl p-4 border border-amber-200">
          <p className="text-gray-700 text-center">
            💡 Skor kecocokan dihitung menggunakan algoritma K-Nearest Neighbor (KNN)
          </p>
        </div>
      </div>
    </div>
  );
}
