import { useState } from 'react';
import { ArrowLeft, Cloud, Sun, CloudRain, Coffee, Clock } from 'lucide-react';
import { UserPreference } from '../MobileApp';

interface PreferenceScreenProps {
  onSubmit: (preference: UserPreference) => void;
  onBack: () => void;
}

export function PreferenceScreen({ onSubmit, onBack }: PreferenceScreenProps) {
  const [acidity, setAcidity] = useState(5);
  const [body, setBody] = useState(5);
  const [aroma, setAroma] = useState(5);
  const [weather, setWeather] = useState('sunny');
  const [time, setTime] = useState('morning');

  const handleSubmit = () => {
    onSubmit({
      acidity,
      body,
      aroma,
      weather,
      time
    });
  };

  return (
    <div className="min-h-full bg-gradient-to-br from-amber-50 to-orange-50 pt-12">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-900 to-orange-900 px-6 py-6 flex items-center gap-3">
        <button onClick={onBack} className="text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-white">Preferensi Anda</h1>
      </div>

      <div className="px-6 py-6 space-y-6">
        {/* Weather Section */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Cloud className="w-5 h-5 text-amber-900" />
            <h2 className="text-gray-800">Kondisi Cuaca</h2>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={() => setWeather('sunny')}
              className={`p-4 rounded-xl border-2 transition-all ${
                weather === 'sunny'
                  ? 'border-amber-900 bg-amber-50'
                  : 'border-gray-200 bg-white'
              }`}
            >
              <Sun className={`w-8 h-8 mx-auto mb-2 ${
                weather === 'sunny' ? 'text-amber-900' : 'text-gray-400'
              }`} />
              <p className={`text-center ${
                weather === 'sunny' ? 'text-amber-900' : 'text-gray-600'
              }`}>Cerah</p>
            </button>
            <button
              onClick={() => setWeather('cloudy')}
              className={`p-4 rounded-xl border-2 transition-all ${
                weather === 'cloudy'
                  ? 'border-amber-900 bg-amber-50'
                  : 'border-gray-200 bg-white'
              }`}
            >
              <Cloud className={`w-8 h-8 mx-auto mb-2 ${
                weather === 'cloudy' ? 'text-amber-900' : 'text-gray-400'
              }`} />
              <p className={`text-center ${
                weather === 'cloudy' ? 'text-amber-900' : 'text-gray-600'
              }`}>Berawan</p>
            </button>
            <button
              onClick={() => setWeather('rainy')}
              className={`p-4 rounded-xl border-2 transition-all ${
                weather === 'rainy'
                  ? 'border-amber-900 bg-amber-50'
                  : 'border-gray-200 bg-white'
              }`}
            >
              <CloudRain className={`w-8 h-8 mx-auto mb-2 ${
                weather === 'rainy' ? 'text-amber-900' : 'text-gray-400'
              }`} />
              <p className={`text-center ${
                weather === 'rainy' ? 'text-amber-900' : 'text-gray-600'
              }`}>Hujan</p>
            </button>
          </div>
        </div>

        {/* Time Section */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Clock className="w-5 h-5 text-amber-900" />
            <h2 className="text-gray-800">Waktu Konsumsi</h2>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={() => setTime('morning')}
              className={`p-4 rounded-xl border-2 transition-all ${
                time === 'morning'
                  ? 'border-amber-900 bg-amber-50'
                  : 'border-gray-200 bg-white'
              }`}
            >
              <p className={`text-center ${
                time === 'morning' ? 'text-amber-900' : 'text-gray-600'
              }`}>Pagi</p>
              <p className="text-center text-gray-400">06-11</p>
            </button>
            <button
              onClick={() => setTime('afternoon')}
              className={`p-4 rounded-xl border-2 transition-all ${
                time === 'afternoon'
                  ? 'border-amber-900 bg-amber-50'
                  : 'border-gray-200 bg-white'
              }`}
            >
              <p className={`text-center ${
                time === 'afternoon' ? 'text-amber-900' : 'text-gray-600'
              }`}>Siang</p>
              <p className="text-center text-gray-400">12-17</p>
            </button>
            <button
              onClick={() => setTime('evening')}
              className={`p-4 rounded-xl border-2 transition-all ${
                time === 'evening'
                  ? 'border-amber-900 bg-amber-50'
                  : 'border-gray-200 bg-white'
              }`}
            >
              <p className={`text-center ${
                time === 'evening' ? 'text-amber-900' : 'text-gray-600'
              }`}>Malam</p>
              <p className="text-center text-gray-400">18-23</p>
            </button>
          </div>
        </div>

        {/* Taste Preferences */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Coffee className="w-5 h-5 text-amber-900" />
            <h2 className="text-gray-800">Profil Rasa</h2>
          </div>

          {/* Acidity */}
          <div className="bg-white rounded-xl p-4 mb-3">
            <div className="flex justify-between mb-2">
              <span className="text-gray-700">Keasaman (Acidity)</span>
              <span className="text-amber-900">{acidity}/10</span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              value={acidity}
              onChange={(e) => setAcidity(Number(e.target.value))}
              className="w-full accent-amber-900"
            />
            <div className="flex justify-between mt-1">
              <span className="text-gray-400">Rendah</span>
              <span className="text-gray-400">Tinggi</span>
            </div>
          </div>

          {/* Body */}
          <div className="bg-white rounded-xl p-4 mb-3">
            <div className="flex justify-between mb-2">
              <span className="text-gray-700">Kekentalan (Body)</span>
              <span className="text-amber-900">{body}/10</span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              value={body}
              onChange={(e) => setBody(Number(e.target.value))}
              className="w-full accent-amber-900"
            />
            <div className="flex justify-between mt-1">
              <span className="text-gray-400">Ringan</span>
              <span className="text-gray-400">Kental</span>
            </div>
          </div>

          {/* Aroma */}
          <div className="bg-white rounded-xl p-4">
            <div className="flex justify-between mb-2">
              <span className="text-gray-700">Intensitas Aroma</span>
              <span className="text-amber-900">{aroma}/10</span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              value={aroma}
              onChange={(e) => setAroma(Number(e.target.value))}
              className="w-full accent-amber-900"
            />
            <div className="flex justify-between mt-1">
              <span className="text-gray-400">Lembut</span>
              <span className="text-gray-400">Kuat</span>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <button
          onClick={handleSubmit}
          className="w-full bg-gradient-to-r from-amber-900 to-orange-900 text-white py-4 rounded-2xl shadow-lg hover:shadow-xl transition-shadow"
        >
          Cari Rekomendasi Kopi
        </button>
      </div>
    </div>
  );
}
