import { Coffee, Sparkles, MapPin } from 'lucide-react';

interface HomeScreenProps {
  onStart: () => void;
}

export function HomeScreen({ onStart }: HomeScreenProps) {
  return (
    <div className="min-h-full bg-gradient-to-br from-amber-50 to-orange-50 pt-12">
      {/* Header */}
      <div className="px-6 pt-8 pb-6">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Coffee className="w-8 h-8 text-amber-900" />
          <h1 className="text-amber-900">Barista Pintar</h1>
        </div>
        <p className="text-center text-gray-600">Rekomendasi Kopi Personal dengan AI</p>
      </div>

      {/* Hero Image */}
      <div className="px-6 mb-8">
        <div className="relative h-64 bg-gradient-to-br from-amber-900 to-orange-900 rounded-3xl overflow-hidden shadow-xl">
          <div className="absolute inset-0 flex items-center justify-center">
            <Coffee className="w-32 h-32 text-amber-100 opacity-50" />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
          <div className="absolute bottom-6 left-6 right-6 text-white">
            <h2 className="mb-2">Temukan Kopi Favoritmu</h2>
            <p className="text-amber-100">Berdasarkan preferensi & cuaca hari ini</p>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="px-6 mb-8">
        <h2 className="mb-4 text-gray-800">Fitur Unggulan</h2>
        <div className="space-y-3">
          <div className="bg-white rounded-2xl p-4 shadow-md flex items-start gap-4">
            <div className="flex-shrink-0 w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-amber-900" />
            </div>
            <div>
              <h3 className="text-gray-800 mb-1">Rekomendasi AI</h3>
              <p className="text-gray-600">Algoritma KNN untuk rekomendasi akurat</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-md flex items-start gap-4">
            <div className="flex-shrink-0 w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
              <Coffee className="w-6 h-6 text-amber-900" />
            </div>
            <div>
              <h3 className="text-gray-800 mb-1">Kopi UMKM Lokal</h3>
              <p className="text-gray-600">Mendukung produk kopi lokal Indonesia</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-md flex items-start gap-4">
            <div className="flex-shrink-0 w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
              <MapPin className="w-6 h-6 text-amber-900" />
            </div>
            <div>
              <h3 className="text-gray-800 mb-1">Berbagai Daerah</h3>
              <p className="text-gray-600">Kopi dari Aceh, Toraja, Papua, dan lainnya</p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Button */}
      <div className="px-6 pb-8">
        <button
          onClick={onStart}
          className="w-full bg-gradient-to-r from-amber-900 to-orange-900 text-white py-4 rounded-2xl shadow-lg hover:shadow-xl transition-shadow flex items-center justify-center gap-2"
        >
          <Sparkles className="w-5 h-5" />
          Dapatkan Rekomendasi Kopi
        </button>
        <p className="text-center text-gray-500 mt-4">
          Gratis • Cepat • Akurat
        </p>
      </div>
    </div>
  );
}
