import { ArrowLeft, MapPin, Star, Info } from 'lucide-react';
import { Coffee } from '../MobileApp';

interface CoffeeDetailScreenProps {
  coffee: Coffee;
  onBack: () => void;
}

export function CoffeeDetailScreen({ coffee, onBack }: CoffeeDetailScreenProps) {
  return (
    <div className="min-h-full bg-gradient-to-br from-amber-50 to-orange-50 pt-12">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-900 to-orange-900 px-6 py-6 flex items-center gap-3">
        <button onClick={onBack} className="text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-white">Detail Kopi</h1>
      </div>

      {/* Coffee Image */}
      <div className="relative h-64 bg-gradient-to-br from-amber-900 to-orange-900 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="text-6xl mb-4">{coffee.name.substring(0, 2)}</div>
          <h2 className="text-white">{coffee.name}</h2>
        </div>
        
        {/* Match Score Badge */}
        {coffee.matchScore && (
          <div className="absolute top-4 right-4 bg-white rounded-full px-4 py-2 shadow-lg">
            <div className="flex items-center gap-2">
              <Star className="w-5 h-5 text-amber-900 fill-amber-900" />
              <span className="text-amber-900">{coffee.matchScore}% Match</span>
            </div>
          </div>
        )}
      </div>

      <div className="px-6 py-6 space-y-4">
        {/* Basic Info */}
        <div className="bg-white rounded-2xl p-6 shadow-md">
          <div className="flex items-start gap-3 mb-4">
            <MapPin className="w-5 h-5 text-amber-900 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-gray-800 mb-1">Asal</h3>
              <p className="text-gray-600">{coffee.origin}</p>
            </div>
          </div>
          
          <div className="border-t border-gray-200 pt-4">
            <h3 className="text-gray-800 mb-2">Deskripsi</h3>
            <p className="text-gray-600 leading-relaxed">{coffee.description}</p>
          </div>
        </div>

        {/* Characteristics */}
        <div className="bg-white rounded-2xl p-6 shadow-md">
          <h3 className="text-gray-800 mb-4">Karakteristik Rasa</h3>
          
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Keasaman (Acidity)</span>
                <span className="text-amber-900">{coffee.acidity}/10</span>
              </div>
              <div className="bg-gray-200 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-amber-600 to-orange-600 h-2 rounded-full"
                  style={{ width: `${coffee.acidity * 10}%` }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Kekentalan (Body)</span>
                <span className="text-amber-900">{coffee.body}/10</span>
              </div>
              <div className="bg-gray-200 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-amber-600 to-orange-600 h-2 rounded-full"
                  style={{ width: `${coffee.body * 10}%` }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Intensitas Aroma</span>
                <span className="text-amber-900">{coffee.aroma}/10</span>
              </div>
              <div className="bg-gray-200 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-amber-600 to-orange-600 h-2 rounded-full"
                  style={{ width: `${coffee.aroma * 10}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* Flavor Notes */}
        <div className="bg-white rounded-2xl p-6 shadow-md">
          <h3 className="text-gray-800 mb-3">Profil Rasa</h3>
          <div className="flex flex-wrap gap-2">
            {coffee.flavorNotes.map((note, index) => (
              <span
                key={index}
                className="bg-amber-100 text-amber-900 px-4 py-2 rounded-full"
              >
                {note}
              </span>
            ))}
          </div>
        </div>

        {/* Roast Level */}
        <div className="bg-white rounded-2xl p-6 shadow-md">
          <h3 className="text-gray-800 mb-2">Tingkat Roasting</h3>
          <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
            <p className="text-amber-900">{coffee.roastLevel}</p>
          </div>
        </div>

        {/* Price */}
        <div className="bg-gradient-to-r from-amber-900 to-orange-900 rounded-2xl p-6 shadow-md text-white">
          <h3 className="text-white mb-2">Harga</h3>
          <p className="text-amber-100">{coffee.price}</p>
        </div>

        {/* UMKM Info */}
        <div className="bg-amber-50 rounded-xl p-4 border border-amber-200 flex items-start gap-3">
          <Info className="w-5 h-5 text-amber-900 flex-shrink-0 mt-1" />
          <div>
            <h3 className="text-amber-900 mb-1">Mendukung UMKM Lokal</h3>
            <p className="text-gray-700">
              Setiap pembelian membantu petani kopi lokal Indonesia berkembang
            </p>
          </div>
        </div>

        {/* CTA Button */}
        <button className="w-full bg-gradient-to-r from-amber-900 to-orange-900 text-white py-4 rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
          Hubungi UMKM untuk Pembelian
        </button>
      </div>
    </div>
  );
}
