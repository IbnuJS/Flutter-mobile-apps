import { Coffee, Smartphone, Brain, TrendingUp } from 'lucide-react';

interface LandingPageProps {
  onViewApp: () => void;
}

export function LandingPage({ onViewApp }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-brown-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-amber-900 to-orange-900 text-white py-8 px-6 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Coffee className="w-10 h-10" />
            <h1 className="text-center">Sistem Rekomendasi Kopi Menggunakan Machine Learning pada Aplikasi Mobile Barista Pintar untuk Mendukung UMKM Kopi Lokal</h1>
          </div>
          <p className="text-center text-amber-100">Penelitian & Prototype Mobile Apps</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Abstract Section */}
        <section className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <h2 className="flex items-center gap-3 mb-6 text-amber-900">
            <Brain className="w-8 h-8" />
            Abstrak
          </h2>
          <div className="space-y-4 text-gray-700 leading-relaxed">
            <p>
              Perkembangan teknologi kecerdasan buatan (Artificial Intelligence/AI) telah mempengaruhi berbagai sektor industri, termasuk bisnis kopi yang saat ini berkembang pesat di kalangan pelaku Usaha Mikro, Kecil, dan Menengah (UMKM). Penelitian ini bertujuan untuk mengembangkan aplikasi mobile "Barista Pintar" yang dapat memberikan rekomendasi jenis kopi berdasarkan preferensi pengguna, kondisi cuaca, dan waktu konsumsi.
            </p>
            <p>
              Sistem ini menggunakan metode Content-Based Filtering dengan algoritma K-Nearest Neighbor (KNN) untuk mencocokkan profil rasa pengguna dengan karakteristik kopi seperti tingkat keasaman, kekentalan, dan aroma. Aplikasi dibangun menggunakan Flutter sebagai antarmuka pengguna dan Python (scikit-learn) untuk pemodelan machine learning.
            </p>
            <p>
              Berdasarkan hasil pengujian terhadap 50 responden pengguna, sistem menunjukkan tingkat kepuasan sebesar 87%, dengan waktu rekomendasi rata-rata 1,8 detik per permintaan. Hasil tersebut membuktikan bahwa sistem rekomendasi berbasis AI ini dapat meningkatkan pengalaman pengguna dan membantu pelaku UMKM kopi dalam memberikan layanan yang lebih personal dan efisien.
            </p>
          </div>

          {/* Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 text-center">
              <div className="text-amber-900 mb-2">Tingkat Kepuasan</div>
              <div className="text-amber-900">87%</div>
            </div>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 text-center">
              <div className="text-amber-900 mb-2">Waktu Rekomendasi</div>
              <div className="text-amber-900">1.8 detik</div>
            </div>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 text-center">
              <div className="text-amber-900 mb-2">Responden</div>
              <div className="text-amber-900">50 pengguna</div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <h2 className="flex items-center gap-3 mb-6 text-amber-900">
            <Smartphone className="w-8 h-8" />
            Fitur Aplikasi Barista Pintar
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                <Coffee className="w-6 h-6 text-amber-900" />
              </div>
              <div>
                <h3 className="text-amber-900 mb-2">Rekomendasi Personal</h3>
                <p className="text-gray-600">Sistem memberikan rekomendasi kopi berdasarkan preferensi rasa, cuaca, dan waktu konsumsi</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                <Brain className="w-6 h-6 text-amber-900" />
              </div>
              <div>
                <h3 className="text-amber-900 mb-2">Machine Learning</h3>
                <p className="text-gray-600">Menggunakan algoritma K-Nearest Neighbor (KNN) untuk analisis yang akurat</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-amber-900" />
              </div>
              <div>
                <h3 className="text-amber-900 mb-2">Mendukung UMKM</h3>
                <p className="text-gray-600">Membantu pelaku UMKM kopi lokal meningkatkan layanan dan penjualan</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                <Smartphone className="w-6 h-6 text-amber-900" />
              </div>
              <div>
                <h3 className="text-amber-900 mb-2">User Friendly</h3>
                <p className="text-gray-600">Interface yang mudah digunakan dan responsif di berbagai perangkat</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-gradient-to-r from-amber-900 to-orange-900 rounded-2xl shadow-xl p-8 text-center text-white">
          <h2 className="mb-4">Lihat Prototype Aplikasi</h2>
          <p className="mb-6 text-amber-100">
            Klik tombol di bawah untuk mencoba prototype interaktif aplikasi Barista Pintar
          </p>
          <button
            onClick={onViewApp}
            className="bg-white text-amber-900 px-8 py-3 rounded-full hover:bg-amber-50 transition-colors inline-flex items-center gap-2"
          >
            <Smartphone className="w-5 h-5" />
            Buka Prototype Aplikasi
          </button>
        </section>

        {/* Methodology Section */}
        <section className="bg-white rounded-2xl shadow-xl p-8 mt-8">
          <h2 className="mb-6 text-amber-900">Metodologi Penelitian</h2>
          <div className="space-y-4">
            <div className="border-l-4 border-amber-500 pl-4">
              <h3 className="text-amber-900 mb-2">Metode: Content-Based Filtering</h3>
              <p className="text-gray-600">
                Sistem menganalisis karakteristik kopi (keasaman, kekentalan, aroma) dan mencocokkannya dengan profil preferensi pengguna
              </p>
            </div>
            <div className="border-l-4 border-amber-500 pl-4">
              <h3 className="text-amber-900 mb-2">Algoritma: K-Nearest Neighbor (KNN)</h3>
              <p className="text-gray-600">
                Menggunakan KNN untuk mencari kopi dengan karakteristik terdekat dengan preferensi pengguna
              </p>
            </div>
            <div className="border-l-4 border-amber-500 pl-4">
              <h3 className="text-amber-900 mb-2">Teknologi: Flutter & Python</h3>
              <p className="text-gray-600">
                Flutter untuk antarmuka mobile yang responsif, Python (scikit-learn) untuk pemodelan ML
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-amber-900 to-orange-900 text-white py-6 px-6 mt-12">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-amber-100">© 2025 Barista Pintar - Sistem Rekomendasi Kopi Berbasis Machine Learning</p>
          <p className="text-amber-200 mt-2">Mendukung UMKM Kopi Lokal Indonesia</p>
        </div>
      </footer>
    </div>
  );
}
