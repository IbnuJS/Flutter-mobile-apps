import { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { MobileApp } from './components/MobileApp';

export default function App() {
  const [showApp, setShowApp] = useState(false);

  if (showApp) {
    return <MobileApp onBack={() => setShowApp(false)} />;
  }

  return <LandingPage onViewApp={() => setShowApp(true)} />;
}
